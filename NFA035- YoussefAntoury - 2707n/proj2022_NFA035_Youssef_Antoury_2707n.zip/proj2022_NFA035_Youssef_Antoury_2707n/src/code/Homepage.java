package code;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import javax.swing.*;

@SuppressWarnings("serial")
public class Homepage extends JFrame implements ActionListener{
	
	JButton contactBtn = new JButton("Contacts");
	JButton groupBtn = new JButton("Groups");
	JLabel titleCard = new JLabel("Gestion des Contacts");
	
	Homepage( ){
	setSize (500, 650);
	setTitle("Projet NFA035");
        
	//setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        
        
        WindowListener exitListener = new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                        try {
                        FileOutputStream out = new FileOutputStream("seqNum.out");
                        ObjectOutputStream oos = new ObjectOutputStream(out);
                        oos.writeObject(Contact.getSequenceNum());
                        oos.flush();
                       } catch (Exception cc) {
                        System.out.println("Problem serializing: " + cc);
                        }
                        
                         try {
                        FileOutputStream out = new FileOutputStream("contactList.out");
                        ObjectOutputStream oos = new ObjectOutputStream(out);
                        oos.writeObject(Contact.getContactList());
                        oos.flush();
                       } catch (Exception cc) {
                        System.out.println("Problem serializing: " + cc);
                        }
                        
                         try {
                        FileOutputStream out = new FileOutputStream("telephoneList.out");
                        ObjectOutputStream oos = new ObjectOutputStream(out);
                        oos.writeObject(Contact.getTelephoneList());
                        oos.flush();
                       } catch (Exception cc) {
                        System.out.println("Problem serializing: " + cc);
                        }
                        
                        try {
                        FileOutputStream out = new FileOutputStream("grpNamesList.out");
                        ObjectOutputStream oos = new ObjectOutputStream(out);
                        oos.writeObject(Group.getGrpNamesList());
                        oos.flush();
                       } catch (Exception cc) {
                        System.out.println("Problem serializing: " + cc);
                        }
                        
                           try {
                        FileOutputStream out = new FileOutputStream("grpList.out");
                        ObjectOutputStream oos = new ObjectOutputStream(out);
                        oos.writeObject(Group.getGrpList());
                        oos.flush();
                       } catch (Exception cc) {
                        System.out.println("Problem serializing: " + cc);
                        }
                        
                   System.exit(0);
                }
          //  }
        };
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
      addWindowListener(exitListener);

        
       
                        
        
        
	Container cp = getContentPane();
	cp.setBackground (Color.cyan);
	cp.setLayout (new BorderLayout());
	setVisible(true);
	JPanel contactBtnPanel =new JPanel();
	JPanel titlePanel =new JPanel();
	titlePanel.setLayout(new FlowLayout());
	titlePanel.setSize(500,70);
	contactBtnPanel.setLayout(new BoxLayout(contactBtnPanel, BoxLayout.Y_AXIS));
	//contactBtnPanel.setSize(120,650);
	contactBtn.setMaximumSize(new Dimension(100, 30));
	contactBtn.addActionListener(this);
	contactBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
	groupBtn.setMaximumSize(new Dimension(100, 30));
	groupBtn.addActionListener(this);
	groupBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
	contactBtnPanel.add(Box.createRigidArea(new Dimension(120,30)));
	contactBtnPanel.add(contactBtn);
	contactBtnPanel.add(Box.createRigidArea(new Dimension(120,30)));
	contactBtnPanel.add(groupBtn);
	titlePanel.add(titleCard);
	cp.add(contactBtnPanel,BorderLayout.WEST);
	titleCard.setFont(new Font("Sans Serif",Font.BOLD,14));
	cp.add(titlePanel,BorderLayout.NORTH);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		Object pressedObj = event.getSource();
	if(pressedObj==contactBtn) {
		ContactFrame contactsWindow = new ContactFrame();
		}
	if(pressedObj==groupBtn) {
		GroupFrame grpF = new GroupFrame();
	}

	
	}
}
