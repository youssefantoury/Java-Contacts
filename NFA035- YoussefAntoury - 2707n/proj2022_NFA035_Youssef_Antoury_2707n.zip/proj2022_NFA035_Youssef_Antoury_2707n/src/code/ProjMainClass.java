package code;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
public class ProjMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//generateContactList();
		/*Contact m =new Contact("joeee  eeeee","khoury","maarab","03","546734");
		new Contact("charbel","aintoury","beirut","81","546734");
		new Contact("yolla","khoury","maarab","05","523734");
		new Contact("joseph","al khoury","ghosta","04","536734");
		new Contact("joey","3ouwed","junieh","76","871901");
		new Contact("joy","matar","junieh","76","226921");
		new Contact("youssef","antoury","junieh","77","876901");
		new Contact("youssef","antoury","junieh","78","856901");
		Contact u =new Contact("youssef","antoury","beirut","76","555901");
		new Group("grouup1","no desc");
		new Group("graup1","no desc");
		new Group("gaup1","no desc");
		new Group("graup1","no desc");
		new Group("oeeup1","no desc");
		new Group("graup1","no desc");
		new Group("garrup1","no desc");
		new Group("graeep1","no desc");
		new Group("aetteup1","no desc");
		new Group("graup1","no desc");
		new Group("eraeep1","no desc");
		new Group("betteup1","no desc");
		new Group("group2","no desc").addContact(m);
		new Group("group3","no desc").addContact(u);
		m.addNumber(m.getContactId(),"789", "1111");
		m.addNumber(m.getContactId(),"729", "1221");
		u.addNumber(u.getContactId(), "7891", "221");*/
		
                
              
               
		try {
                       FileInputStream in = new FileInputStream("seqNum.out");
                       ObjectInputStream ois = new ObjectInputStream(in);
                        Contact.setSequenceNum((int)(ois.readObject())); 
                        System.out.println(Contact.getSequenceNum()+"seq from file");
                } catch (Exception e) {
                      System.out.println("Problem serializing: " + e);
                       //Contact.setSequenceNum(0); 
                }
		
                
		try {
                       FileInputStream in = new FileInputStream("contactList.out");
                       ObjectInputStream ois = new ObjectInputStream(in);
                        Contact.setContactList((DefaultListModel<Contact>)(ois.readObject()));
                        System.out.println("gotten contact list");
                } catch (Exception e) {
                      System.out.println("Problem serializing: " + e);
                       
                }
                
                try {
                       FileInputStream in = new FileInputStream("telephoneList.out");
                       ObjectInputStream ois = new ObjectInputStream(in);
                        Contact.setTelephoneList((HashMap<String,Integer>)(ois.readObject()));
                        System.out.println("gotten telephone list");
                } catch (Exception e) {
                      System.out.println("Problem serializing: " + e);
                       
                }
		
		try {
                       FileInputStream in = new FileInputStream("grpNamesList.out");
                       ObjectInputStream ois = new ObjectInputStream(in);
                        Group.setGrpNamesList((ArrayList<String>)(ois.readObject()));
                        System.out.println("gotten group name list");
                } catch (Exception e) {
                      System.out.println("Problem serializing: " + e);
                       
                }
		
                try {
                       FileInputStream in = new FileInputStream("grpList.out");
                       ObjectInputStream ois = new ObjectInputStream(in);
                        Group.setGrpList((ArrayList<Group>)(ois.readObject()));
                        System.out.println("gotten grouplist");
                } catch (Exception e) {
                      System.out.println("Problem serializing: " + e);
                       
                }
                
		Homepage j =new Homepage();
		//new Contact("jiji","jojo","ville"+1,1,1001);
		//Contact jo =new Contact("jiji","jojo","ville"+1,1,1001);
		//jo.addNumber(0, 1,1001);
		
	}

	static void generateContactList() {
		//Contact t[]= new Contact [30];
		//for(int i=0; i<30; i++) {
			// t[i]= new Contact("jiji","jojo","ville"+i,i,i+1000);
			
		}
		
	
	}
	

